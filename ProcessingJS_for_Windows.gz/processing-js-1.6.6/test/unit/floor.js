
function _runTest() {
  _checkEqual(2, floor(2.88));
}
